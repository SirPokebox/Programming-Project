package com.example.railwayapplication;
/** All imports required are listed below
 *
 * @author Rhys Clinch
 */
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.ExecutionException;
/**
 * Method below gives the app GPS permissions once the user Allows it.
 * For this to work, I had to allow the manifest permissions within the AndroidManifest.xml.
 * If the user does not allow GPS access, the app closes.
 *
 */
public class MainActivity extends AppCompatActivity {

    /*
    List of variables used are below.
     */
    TableLayout Tb1;
    String kmDistance;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String[] requiredPermissions = {Manifest.permission.INTERNET, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION};
        boolean Access = true;
        //for loop to check if permissions are correct
        for (int i = 0; i < requiredPermissions.length; i++) {
            int result = ActivityCompat.checkSelfPermission(this, requiredPermissions[i]);
            if (result != PackageManager.PERMISSION_GRANTED) {
                Access = false;
            }
        }
        //if permissions are not ok, close the application.
        if (!Access) {
            ActivityCompat.requestPermissions(this, requiredPermissions, 1);
            System.exit(0);

        //if permissions are ok, run this method which updates GPS location.
        } else {
            LocationManager LocMan = (LocationManager) getSystemService(LOCATION_SERVICE);
            LocMan.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, new LocationListener() {
                @Override

                public void onLocationChanged(Location location) {
                    float lati = 0, lon = 0;
                    lati = (float) location.getLatitude();
                    lon = (float) location.getLongitude();

                    Location CurrentLocation = new Location("Starting Point");
                    CurrentLocation.setLatitude(lati);
                    CurrentLocation.setLongitude(lon);

                    ((TextView) findViewById(R.id.lati)).setText("Latitude: " + lati + "\n" + "Longitude " + lon);
                }

                @Override
                public void onStatusChanged(String provider, int status, Bundle extras) {

                }

                @Override
                public void onProviderEnabled(String provider) {

                }

                @Override
                public void onProviderDisabled(String provider) {

                }
                /*
                Below is the method that would have been used to calculate the distance between the user's current location and the railway station
                However, could not figure out how to provide RailwayStation with the latitude and longitude of stations.
                Method below convert the result into Kilometers away from the stations.
                 */

                public String DistanceBetween(Location CurrentLocation , Location RailwayStation){

                    double R = 6372.8;
                    double latitude1 = CurrentLocation.getLatitude();
                    double longitude1 = CurrentLocation.getLongitude();
                    double latitude2 = RailwayStation.getLatitude();
                    double longitude2 = RailwayStation.getLongitude();

                    double distanceLat = Math.toRadians(latitude2 - latitude1);
                    double distanceLon = Math.toRadians(longitude2 - longitude1);

                    latitude1 = Math.toRadians(latitude1);
                    latitude2 = Math.toRadians(latitude2);

                    double a = Math.sin(distanceLat/2) * Math.sin(distanceLat/2) + Math.sin(distanceLon/2) * Math.sin(distanceLon/2) * Math.cos(latitude1) * Math.cos(latitude2);
                    double c = 2 *Math.asin(Math.sqrt(a));
                    double d = R*c;

                    double kmRounded = Math.round(d*100.0)/100.0;

                    String kmDistance = (kmRounded + "Kilometers");

                    return kmDistance;
                }
            });
        }


    }
    /*
    Below is the method used once the user clicks the Search button
    it establishes a connection with the server and calls the HTTPConnect() class.
    Once called, a for loop is used that extracts all the JSON data from the server.
    It then adds the results into a table layout for an easy to read format.
     */
    public void ConnectToServer(View v) {
//    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
//    StrictMode.setThreadPolicy(policy);

        ConnectivityManager connmgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connmgr.getActiveNetworkInfo();
        Tb1 = (TableLayout) findViewById(R.id.RailTable);
        Tb1.removeAllViews();

        if (networkInfo != null && networkInfo.isConnected()) {

            try {

                HTTPConnect makeConnection = new HTTPConnect();
                String server = ("http://10.0.2.2:8080/stations?lat=53.472&lng=-2.44");
                JSONArray json = makeConnection.execute(server).get();
                JSONArray RailwayStations = new JSONArray();

                for (int i = 0; i < json.length(); i++) {
                    JSONObject jsonOb = (JSONObject) json.get(i);

                 /*
                 creates the table layout here within the for loop.
                  */
                    TableRow station1 = new TableRow(this);
                    TextView coll1 = new TextView(this);
                    TableRow station2 = new TableRow(this);
                    TextView coll2 = new TextView(this);
                    TableRow station3 = new TableRow(this);
                    TextView coll3 = new TextView(this);

                    try {
                        coll1.setText(String.valueOf("Station: " + jsonOb.getString("StationName") + ", (Lat: " + jsonOb.getString("Latitude") + ", Long: " + jsonOb.getString("Longitude") + ")"));
                        coll3.setText("You are " + kmDistance + " away!");
                    /*
                    catch exception in case a JSON one occurs.
                     if the try cannot find any station information, it will do this.
                     */
                    } catch (JSONException je) {
                        coll1.setText("Cannot find station details!");
                    }
                    /*
                    adds the collumns into the table layout.
                     */
                    station1.addView(coll1);
                    station2.addView(coll2);
                    station3.addView(coll3); //use me to display KM difference
                    Tb1.addView(station1);
                    Tb1.addView(station2);
                    Tb1.addView(station3); //use me to display KM difference

                }

             /*
             These are the catch methods below that handle all the exceptions that may occur.
              */
            } catch (JSONException je) {
                je.printStackTrace();
            } catch (InterruptedException i) {
                i.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            } catch (NullPointerException ioe) {
                ioe.printStackTrace();
            }

        } else {

        }





    }
}
