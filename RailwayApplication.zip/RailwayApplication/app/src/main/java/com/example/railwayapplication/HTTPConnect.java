package com.example.railwayapplication;
/** All imports required are listed below
 *
 * @author Rhys Clinch
 */

import android.os.AsyncTask;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Threading class that runs in the background, whilst using AsyncTask.
 * Establishes a connection once called in MainActivity.
 */

public class HTTPConnect extends AsyncTask<String, Void, JSONArray> {

    @Override
    protected JSONArray doInBackground(String... param) {

        try {

            URL server = null;
            server = new URL(param[0]);
            HttpURLConnection connection = (HttpURLConnection) server.openConnection();
            InputStreamReader ins = new InputStreamReader(connection.getInputStream());
            BufferedReader in = new BufferedReader(ins);
            String line = "";
            while ((line = in.readLine()) != null) {

                JSONArray json = new JSONArray(line);
                return json;
            }

        } catch (IOException ioe) {
            ioe.printStackTrace();
        } catch (JSONException je) {
            je.printStackTrace();
        }

    return null;
}
}


